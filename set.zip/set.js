﻿//uploaded on 30/9/2023, 17:11
const heightRatio = 19.5, widthRatio = 9; //Για ορατή μπάρα στο κινητό πάνω και κάτω: heightRatio = 17.4. Για full screen: heightRatio = 19.5
const shapeWidth = 294, shapeHeight = 153;
const shadowOffset = 20;
const shapeWidthOffset = 60, shapeBetweenOffset = 180, cardHeight = 620;
const cardWidthOffset = 500, cardHeightOffset = 700, topOffset = 200;
const cardsTotal = 81;
const scaleFactor = 1.2676;
const startingTime = 5*60*60 + 60; //First factor is the minutes. Second factor is the frame rate
const addCardsLimit = 1; //Below this number 3 more cards are added
let cards = [], shapes = [], selectedCardsArray = [], colors = [], rowImages = [];
let entries=[], list=[], new_entry=[], hiscores=[];
let newEntryPos = 99;
let entryShown = false;
let newHiScore, playerName, formattedNumber, inp, scoreSession, buttonOK, soundPlay;
let scale, cardRows, cardColumns;
let cardsSelected, canClick, score, score2, unusedCardCounter, message1, message2, clockCounter, previousCounter;
let gameStatus, infoStatus, onePlayer;
let gameFont, hiScoresFont, exitButton, pauseButton, infoButton, hiScoresButton, menuLogo, vsTimerImage, vsPlayerImage, highScoresTable, infoFrame, closeButton, leftArrowButton, rightArrowButton;
let success, failure, clapping, timesupSound, setSound, selectionSound;
let backgroundColor, shadowColor, menuColor, infoColor;
let threeCardsSequenceFlag, setFlag, timesUpSequenceFlag, timesupFrameCount, addCardsSequenceFlag, startingScale, reduceCardsSequenceFlag, collectCardsSequenceFlag, cardsImage, direction;
let cnv, g;
let noSleep = new NoSleep();
let player1DarkColor, player1LightColor, player2DarkColor, player2LightColor;
let showArrowsSequenceFlag, setAnnounced, setCount, setFlash;

function preload() {
  hiscores = loadStrings("boring_data_file.txt");
  gameFont = loadFont("BRLNSDB.TTF");
  hiScoresFont = loadFont("seguisb.ttf");
  exitButton = loadImage("exit.png");
  pauseButton = loadImage("pause.png");
  infoButton = loadImage("info.png");
  hiScoresButton = loadImage("hiscores.png");
  menuLogo = loadImage("set_logo.png");
  vsTimerImage = loadImage("player-vs-timer2.png");
  vsPlayerImage = loadImage("player-vs-player.png");
  highScoresTable = loadImage("leaderboard.jpg");
  infoFrame = loadImage("info_frame.png");
  closeButton = loadImage("close_button.png");
  leftArrowButton = loadImage("left_arrow_button.png");
  rightArrowButton = loadImage("right_arrow_button.png");
  exampleImage1 = loadImage("example 1 - 4 different.png");
  exampleImage2 = loadImage("example 2 - 2 different.png");
  success = createAudio("success.mp3");
  failure = createAudio("failure.mp3");
  clapping = createAudio("clapping-sound.mp3");
  timesupSound = createAudio("times_up.wav");
  setSound = createAudio("set_sound.mp3");
  selectionSound = createAudio("selection.mp3");

  shapes[0] = [];
  shapes[0][0] = loadImage("bean_blank.png");
  shapes[0][1] = loadImage("bean_stripes.png");
  shapes[0][2] = loadImage("bean_filled.png");
  shapes[1] = [];
  shapes[1][0] = loadImage("diamond_blank.png");
  shapes[1][1] = loadImage("diamond_stripes.png");
  shapes[1][2] = loadImage("diamond_filled.png");
  shapes[2] = [];
  shapes[2][0] = loadImage("oval_blank.png");
  shapes[2][1] = loadImage("oval_stripes.png");
  shapes[2][2] = loadImage("oval_filled.png");
}

function setup() {
  getAudioContext().suspend();  //According to the Chrome policy, sounds should be enabled by a user gesture. p5 site suggests that this should be the initial setting.
  if (iOS()) {
    soundPlay = false;
  } else {
    soundPlay = true ;
  }
  if (windowWidth > windowHeight*widthRatio/heightRatio ) {
    deviceWidth = windowHeight*widthRatio/heightRatio;
    deviceHeight = windowHeight;
  } else {
    deviceWidth = windowWidth;
    deviceHeight = deviceWidth*heightRatio/widthRatio;
  }
  p = deviceWidth / 280; // The smallest windowWidth size of any device (Galaxy Fold) is 280
  h = deviceHeight / 654; // The smallest windowHeight size of any device (Galaxy Fold) is 654
  playerName = "";
  backgroundColor = color(230, 220, 230);
  shadowColor = color(backgroundColor.levels[0]/1.5, backgroundColor.levels[1]/1.5, backgroundColor.levels[2]/1.5);
  menuColor = color(206, 255, 255);
  infoColor = color(186, 235, 255);
  colors = [color(255, 0, 100), color(50, 200, 0), color(50, 50, 255)];
  player1DarkColor = color(0, 130, 130);
  player1LightColor = color(0, 245, 245);
  player2DarkColor = color(140, 80, 90);
  player2LightColor = color(255, 140, 160);

  cnv = createCanvas(deviceWidth, deviceHeight);
  g = createGraphics(deviceWidth, deviceHeight);
  cnv.id("mycanvas");

  timesupSound.volume(0.8);
  clapping.volume(1);
  success.volume(1);
  failure.volume(0.5);
  setSound.volume(0.8);
  selectionSound.volume(0.8);

  textFont(gameFont);
  createButtons();
  createEntries();
  createCards();

  //gameStatus = 0; // main menu
  canClick = true;
  gameStatus = -1; // how to play
  loop();
}

function draw() {
  if (gameStatus == 9) { // game
    if (onePlayer) {
      clock();
    } else { // two players
      if (showArrowsSequenceFlag) {
        if (setAnnounced == 0) {
          showArrowsSequence(2); // show 2 arrows
        } else {
          showArrowsSequence(1); // show 1 arrow
        }
      } else if (setAnnounced != 0) {
        setCount++;
        if (setCount > 300) {
          if (setCount % 20 == 0) {
            setFlash *= -1;
            showCards(true);
          }
        }
        if (setCount > 600) {
          //print("time's up for choosing 3 cards");
          setFlash = -1;
          canClick = false;
          threeCardsSequenceFlag = true;
          setFlag = false;
          frameCount = -1;
          setCount = 0;
          if (soundPlay) { failure.play(); }
        }
      }
    }
    //if (threeCardsSequenceFlag && clockCounter > 60) { // So that it doesn't overlap with the time's up sequence. 180 millisecs are 2 secs because Last 60 millisecs don't count.
    if (threeCardsSequenceFlag) { // So that it doesn't overlap with the time's up sequence. 180 millisecs are 2 secs because Last 60 millisecs don't count.
      if (setFlag) { // set
        threeCardsSequence("SET !", 10, color(63, 128, 0), color(125, 255, 0), color(0, 180, 0));
      } else { // no set
        threeCardsSequence("NO SET", -10, color(128, 63, 0), color(255, 125, 0), color(255, 0, 0));
      }
    } else if (addCardsSequenceFlag) {
      addCardsSequence();
    } else if (reduceCardsSequenceFlag) {
      reduceCardsSequence();
    } else if (collectCardsSequenceFlag) {
      collectCardsSequence();
    }
    if (timesUpSequenceFlag) {
      timesUpSequence();
    }
  } else if (gameStatus == 8) { // pause
    noLoop();
    pauseGame();
  } else if (gameStatus == 0) { // menu
    document.getElementById("mycanvas").setAttribute("class", "animation-right");
    noLoop();
    mainMenu();
    setTimeout(() => {
      document.getElementById("mycanvas").removeAttribute("class", "animation-right");
    }, 500);
  } else if (gameStatus == 1) { // info
    document.getElementById("mycanvas").setAttribute("class", "animation-left");
    noLoop();
    info1();
    setTimeout(() => {
      document.getElementById("mycanvas").removeAttribute("class", "animation-left");
    }, 500);
  } else if (gameStatus == 2) { // leaderboard
    document.getElementById("mycanvas").setAttribute("class", "animation-left");
    noLoop();
    showHiscores();
    setTimeout(() => {
      document.getElementById("mycanvas").removeAttribute("class", "animation-left");
    }, 500);
  } else if (gameStatus == -1) { // how to play
    noLoop();
    howToPlay();
  }
}

function pauseGame() {
  background(backgroundColor);
  deselectAllCards();
  previousCounter = clockCounter; //Force display the score
  clock();
  showScore();
  push();
  translate(deviceWidth/2, deviceHeight/2);
  textSize(60*p);
  textAlign(CENTER, BOTTOM);
  strokeWeight(7*p);
  stroke(65);
  fill(130);
  text("PAUSED", 0, 0);
  textSize(35*p);
  fill(0);
  noStroke();
  text("Tap to resume", 0, 60*h);
  pop();

  push();
  strokeWeight(7*p);
  translate(0, 0);
  stroke(0);
  noFill();
  rectMode(CORNER);
  rect(7*p, 80*h, deviceWidth - 14*p, deviceHeight - 87*h, 20*p);
  pop();
}

function mainMenu() {
  //print("main menu");
  getProfileData();
  deselectAllCards();
  shuffleArray(cards, 0);
  scale = 0.18;
  cardRows = 4, cardColumns = 3;
  canClick = true;
  threeCardsSequenceFlag = false;
  addCardsSequenceFlag = false;
  reduceCardsSequenceFlag = false;
  timesUpSequenceFlag = false;
  collectCardsSequenceFlag = false;
  showArrowsSequenceFlag = false;
  setAnnounced = 0;
  setCount = 0;
  setFlash = -1; // flash is off
  score2 = 0;
  unusedCardCounter = cardRows*cardColumns;
  message1 = "Sets on"; message2 = "board: ";
  clockCounter = startingTime;
  previousCounter = clockCounter; //The previousCounter makes the clock() function to draw the clock once every second instead of every frame. This significantly reduces the CPU overload.
  if (newEntryPos == 99) {
    score = 0;
    document.body.style.backgroundColor = menuColor; //change the color outside the canvas
    background(menuColor); //change the color inside the canvas
    imageMode(CENTER);
    image(menuLogo, deviceWidth/2, 120*h, deviceWidth/1.1, 150*h);
    image(vsTimerImage, deviceWidth/2, deviceHeight/2 - 20*h, deviceWidth/1.05, 130*h);
    image(infoButton, 50*p, deviceHeight - 50*h, 70*p, 70*p);
    image(hiScoresButton, deviceWidth - 50*p, deviceHeight - 50*h, 70*p, 70*p);
    image(vsPlayerImage, deviceWidth/2, deviceHeight*3/4 - 20*h, deviceWidth/1.05, 130*h);
  } else { // newEntryPos < 99
    if (soundPlay) { clapping.play(); }
    if (playerName == "") {
      gameStatus = 3; // input name
      inputName();
    } else {
      gameStatus = 2; // leaderboard
      updateLeaderboard();
      checkNewName();
      showHiscores();
    }
  }
}

function clock() {
  clockCounter--;
  const c = floor(clockCounter / 60);
  if (c < previousCounter && ! timesUpSequenceFlag) { // timesUpSequenceFlag is used for preventing the clock to go below zero
    previousCounter = c;
    push();
    translate(0, 0);
    fill(backgroundColor);
    noStroke();
    rect(0, 0, 120*p, 72*h);

    textSize(50*p);
    textAlign(LEFT, TOP);
    strokeWeight(7*p);
    stroke(120, 120, 0);
    fill(240, 240, 0);
    let str = floor(c / 60) + ":" + (c - floor(c / 60) * 60).toLocaleString('en-US', {minimumIntegerDigits: 2, useGrouping: false});
    text(str, 10*p, 5*h);
    pop();
    if (c <= 0) {
      if (! timesUpSequenceFlag) { // Without this check the frameCount is set to 0 before it reaches 60 frames because of if (c <= 0)
        //print("Time's up");
        if (soundPlay) { timesupSound.play(); }
        timesupFrameCount = 0;
        timesUpSequenceFlag = true;
        canClick = false;
      }
    }
  }
}

function showScore() {
  push();
  translate(0, 0);
  textSize(50*p);
  strokeWeight(7*p);
  textAlign(RIGHT, TOP);
  stroke(player1DarkColor);
  fill(player1LightColor);
  text(score, deviceWidth - 10*p, 5*h);
  if (! onePlayer) {
    textAlign(LEFT, TOP);
    stroke(player2DarkColor);
    fill(player2LightColor);
    text(score2, 10*p, 5*h);
  }
  pop();
}

function cS(rev) {
  let sumColors, sumShapes, sumAmounts, sumFills;
  let sets = 0;
  for (let k = 0; k < cardRows*cardColumns - 2; k++) {
    for (let j = k + 1; j < cardRows*cardColumns - 1; j++) {
      for (let i = j + 1; i < cardRows*cardColumns; i++) {
        sumColors = cards[k].color + cards[j].color + cards[i].color;
        sumShapes = cards[k].shape + cards[j].shape + cards[i].shape;
        sumAmounts = cards[k].amount + cards[j].amount + cards[i].amount;
        sumFills = cards[k].fill + cards[j].fill + cards[i].fill;

        if ( (sumColors == 0 || sumColors == 3 || sumColors == 6) &&
             (sumShapes == 0 || sumShapes == 3 || sumShapes == 6) &&
             (sumAmounts == 0 || sumAmounts == 3 || sumAmounts == 6) &&
             (sumFills == 0 || sumFills == 3 || sumFills == 6) ) {
          if (rev) { print(k, j, i); }
          sets++;
        }
      }
    }
  }
  return sets;
}

function isSet() {
  let sumColors = 0, sumShapes = 0, sumAmounts = 0, sumFills = 0;
  for (let i = 0; i < 3; i++) {
    //print(i, "color:", selectedCardsArray[i].color, "shape:", selectedCardsArray[i].shape, "amount:", selectedCardsArray[i].amount, "fill:", selectedCardsArray[i].fill);
    sumColors += selectedCardsArray[i].color;
    sumShapes += selectedCardsArray[i].shape;
    sumAmounts += selectedCardsArray[i].amount;
    sumFills += selectedCardsArray[i].fill;
  }
  //print(" ");
  //print(sumColors, sumShapes, sumAmounts, sumFills);
  if ( (sumColors == 0 || sumColors == 3 || sumColors == 6) &&
       (sumShapes == 0 || sumShapes == 3 || sumShapes == 6) &&
       (sumAmounts == 0 || sumAmounts == 3 || sumAmounts == 6) &&
       (sumFills == 0 || sumFills == 3 || sumFills == 6) ) {
    return true;
  } else {
   return false;
  }
}

function mousePressed() {
  userStartAudio(); //According to the Chrome policy, sounds should be enabled by a user gesture. Equivalent to getAudioContext().resume();
  if (canClick) {
    if (gameStatus == -1) { // do you know how to play set?
      if (mouseX > 81*p && mouseX < deviceWidth - 60*p) {
        if (mouseY > 333*h && mouseY < 405*h) {
          //print("clicked on the No button");
          gameStatus = 1;
          infoStatus = 0; // info1
          loop();
        } else if (mouseY > 463*h && mouseY < 515*h) {
          //print("clicked on the Yes button");
          gameStatus = 0;
          loop();
        }
      }
    } else if (gameStatus == 0) { // main menu
      if (mouseY > deviceHeight/2 - 20*h - 130/2*h && mouseY < deviceHeight/2 - 20*h + 130/2*h) {
        //print("clicked on vs Timer mode");
        document.getElementById("mycanvas").setAttribute("class", "animation-left");
        onePlayer = true;
        gameStatus = 9;
        noSleep.enable(); // keep the screen on!
        showCards(false);
        //cS(true);
        setTimeout(() => {
          document.getElementById("mycanvas").removeAttribute("class", "animation-left");
        }, 500);
        loop();
      } else if (mouseY > deviceHeight*3/4 - 20*h - 130/2*h && mouseY < deviceHeight*3/4 - 20*h + 130/2*h) {
        //print("clicked on vs Player mode");
        document.getElementById("mycanvas").setAttribute("class", "animation-left");
        onePlayer = false;
        gameStatus = 9;
        noSleep.enable(); // keep the screen on!
        showCards(false);
        //cS(true);
        setTimeout(() => {
          document.getElementById("mycanvas").removeAttribute("class", "animation-left");
        }, 500);
        loop();
      } else if (mouseY > deviceHeight - 50*h - 70/2*p) {
        if (mouseX < 50*p + 70*p - 70/2*p) {
          //print("clicked on info button");
          gameStatus = 1; // info
          infoStatus = 0; // info1
          loop();
        } else if (mouseX > deviceWidth - 50*p - 70/2*p) {
          //print("clicked on leaderboard button");
          gameStatus = 2; // leaderboard
          loop();
        }
      }
    } else if (gameStatus == 1) { // info
      if (mouseY > 40*h && mouseY < 85*h && mouseX > deviceWidth - 55*p && mouseX < deviceWidth) {
        //print("clicked on close button");
        gameStatus = 0;
        loop();
      } else { // no click on close button
        if (mouseY > deviceHeight - 55*h && mouseX > deviceWidth - 55*p && mouseX < deviceWidth && infoStatus < 2) {
          //print("clicked on right arrow button");
          infoStatus++;
        } else if (mouseY > deviceHeight - 55*h && mouseX > 35*p && mouseX < 80*p && infoStatus > 0) {
          //print("clicked on left arrow button");
          infoStatus--;
        }
        if (infoStatus == 0) {
          info1();
        } else if (infoStatus == 1) {
          info2();
        } else if (infoStatus == 2) {
          info3();
        }
      }
    } else if (gameStatus == 2) { // leaderboard
      if (mouseY < 40*p && mouseX > deviceWidth - 35*p && mouseX < deviceWidth) {
        //print("clicked on close button");
        gameStatus = 0;
        loop();
      }
    } else if (gameStatus == 8) { // paused
      gameStatus = 9;
      showCards(false);
      loop();
    } else if (gameStatus == 9) { // game
      const marginWidth = (cardWidthOffset + shapeWidth/2 + shapeWidthOffset)*scale*p;
      const marginHeight = cardHeightOffset*scale*h/2;
      setFlag = false;
      // push();
      // translate(0, 0);
      // stroke(0);
      // strokeWeight(1);
      // line(0, topOffset*h - marginHeight, deviceWidth, topOffset*h - marginHeight);
      // line(0, topOffset*h + (2*cardRows - 1)*marginHeight, deviceWidth, topOffset*h + (2*cardRows - 1)*marginHeight);
      // line(deviceWidth/2 - marginWidth, 0, deviceWidth/2 - marginWidth, deviceHeight);
      // line(deviceWidth/2 + marginWidth, 0, deviceWidth/2 + marginWidth, deviceHeight);
      // pop();
      if (mouseY < topOffset*h - marginHeight) {
        //print("clicked on controls");
        if (onePlayer) {
          if (mouseY > 80*h && mouseY < topOffset*h - marginHeight - 10*h) {
            if (mouseX > deviceWidth - 70*p && mouseX < deviceWidth) {
              //print("clicked on pause button");
              gameStatus = 8; // pause
            } else if (mouseX > 10*p && mouseX < 61*p) {
              //print("clicked on exit button");
              gameStatus = 0; // menu
              noSleep.disable(); // let the screen turn off.
            }
          }
        } else { // 2 players
          if (mouseY < topOffset*h - 140*h) {
            if (mouseX > deviceWidth/2 - 30*p && mouseX < deviceWidth/2 + 27*p) {
              //print("clicked on exit button");
              gameStatus = 0; // menu
              noSleep.disable(); // let the screen turn off.
            }
          } else if (mouseY > topOffset*h - 130*h && mouseY < topOffset*h - 75*h) {
            if (mouseX < 80*p) {
              //print("clicked on left set button");
              if (setAnnounced == 0) {
                setAnnounced = 2;
                setFlash = 1;
                showArrowsSequenceFlag = false;
                showCards(true);
                if (soundPlay) { setSound.play(); }
              } else {
                if (! showArrowsSequenceFlag) {
                  showArrowsSequenceFlag = true;
                  frameCount = -1;
                }
              }
            } else if (mouseX > deviceWidth - 82*p) {
              //print("clicked on right set button");
              if (setAnnounced == 0) {
                setAnnounced = 1;
                setFlash = 1;
                showArrowsSequenceFlag = false;
                showCards(true);
                if (soundPlay) { setSound.play(); }
              } else {
                if (! showArrowsSequenceFlag) {
                  showArrowsSequenceFlag = true;
                  frameCount = -1;
                }
              }
            }
          }
        }
      } else if (mouseX < deviceWidth/2 - marginWidth || mouseX > deviceWidth/2 + marginWidth) {
        //print("clicked too left or too right of the cards");
      } else { // clicked on cards
        if (! onePlayer && setAnnounced == 0) {
          if (! showArrowsSequenceFlag) {
            showArrowsSequenceFlag = true;
            frameCount = -1;
          }
        } else { // one player game or a set button has been pressed
          let clickedColumn = int(map(mouseX, deviceWidth/2 - marginWidth, deviceWidth/2 + marginWidth, 0, cardColumns));
          let clickedRow = int(map(mouseY, topOffset*h - marginHeight, topOffset*h + (2*cardRows - 1)*marginHeight, 0, cardRows));
          //if (clickedColumn == cardColumns) { clickedColumn = cardColumns - 1 }; // so that it never returns 3;
          if (clickedRow == cardRows) { clickedRow = cardRows - 1 }; // so that it never returns 4;
          //print(clickedRow, clickedColumn);
          //print(mouseX, mouseY);
          if (! cards[clickedRow*cardColumns + clickedColumn].selected) {
            cards[clickedRow*cardColumns + clickedColumn].selected = true;
            cards[clickedRow*cardColumns + clickedColumn].row = clickedRow;
            cards[clickedRow*cardColumns + clickedColumn].column = clickedColumn;
            //selectedCardsArray.push(cards[clickedRow*cardColumns + clickedColumn]);
            selectedCardsArray.push(Object.assign({}, cards[clickedRow*cardColumns + clickedColumn])); // pushes a clone of the cards[i] object to the array selectedCardsArray, so that changes like deselection of cards in the cards object will not affect the selectedCardsArray
            cardsSelected++;
          } else {
            cards[clickedRow*cardColumns + clickedColumn].selected = false;
            cards[clickedRow*cardColumns + clickedColumn].row = 9;
            cards[clickedRow*cardColumns + clickedColumn].column = 9;
            //const idToDelete = selectedCardsArray.findIndex(obj => obj.id == colorToDelete);
            if (selectedCardsArray[0].id == cards[clickedRow*cardColumns + clickedColumn].id) {
              selectedCardsArray.splice(0, 1); // The array selectedCardsArray can have at most two cards when one of them becomes deselected. Eather the first one matches the card deselected or the other.
            } else {
              selectedCardsArray.splice(1, 1);
            }
            cardsSelected--;
          }
          if (cardsSelected == 3) {
            if (isSet()) {
              setFlag = true;
              if (soundPlay) { success.play(); }
            } else {
              setFlag = false;
              if (soundPlay) { failure.play(); }
            }
            canClick = false;
            threeCardsSequenceFlag = true;
            frameCount = -1;
            setCount = 0;
            loop();
          }
          //print("mouseclicked", cards[clickedRow*cardColumns + clickedColumn].id, clickedRow, clickedColumn, cards[clickedRow*cardColumns + clickedColumn].selected);
          showOneCard(clickedRow*cardColumns + clickedColumn, clickedRow, clickedColumn);
          if (soundPlay) {
            selectionSound.stop();
            selectionSound.play();
          }
        }
      }
    }
  }
  if (gameStatus != 3) { //not in input name
    return false; // prevents multi-clicks
  } else {
    return true; //for the input element to work
  }
}

function showArrowsSequence(num) {
  //print(frameCount);
  const startX1 = 37*p;
  const startX2 = deviceWidth - 54*p;
  const startX0 = deviceWidth/2 - 10*p;
  const thickness = 18*p;
  const heigh = 30*h;
  const outline = 4*h;
  const limitMovement = 100;
  const speed = 3;
  let startY;
  if (frameCount < limitMovement/speed) { // arrows go down
    if (num == 2) {
      startY = -2*heigh + frameCount*speed*h;
    } else {
      startY = -1*heigh + frameCount*speed*h;
    }
  } else if (frameCount < 2*limitMovement/speed) { // arrows go up
    if (num == 2) {
      //startY = 4*heigh - outline - frameCount*speed*h;
      startY = -2*heigh + 2*limitMovement*h - frameCount*speed*h;
    } else {
      //startY = 5.4*heigh - outline - frameCount*speed*h;
      startY = -1*heigh + 2*limitMovement*h - frameCount*speed*h;
    }
  } else { // animation is finished
    showArrowsSequenceFlag = false;
  }
  showCards(true);

  push();
  strokeWeight(outline);
  if (num == 2) { // show 2 arrows
    stroke(player2DarkColor);
    fill(player2LightColor);
    beginShape();
    vertex(startX1, startY);
    vertex(startX1 + thickness, startY);
    vertex(startX1 + thickness, startY + heigh);
    vertex(startX1 + 2*thickness, startY + heigh);
    vertex(startX1 + thickness/2, startY + 2*heigh); // point
    vertex(startX1 - thickness, startY + heigh);
    vertex(startX1, startY + heigh);
    vertex(startX1, startY);
    endShape();

    stroke(player1DarkColor);
    fill(player1LightColor);
    beginShape();
    vertex(startX2, startY);
    vertex(startX2 + thickness, startY);
    vertex(startX2 + thickness, startY + heigh);
    vertex(startX2 + 2*thickness, startY + heigh);
    vertex(startX2 + thickness/2, startY + 2*heigh); // point
    vertex(startX2 - thickness, startY + heigh);
    vertex(startX2, startY + heigh);
    vertex(startX2, startY);
    endShape();
  } else { // show 1 arrow
    if (setAnnounced == 1) {
      stroke(player1DarkColor);
      fill(player1LightColor);
    } else {
      stroke(player2DarkColor);
      fill(player2LightColor);
    }
    beginShape();
    vertex(startX0, startY);
    vertex(startX0 + thickness, startY);
    vertex(startX0 + thickness, startY + heigh);
    vertex(startX0 + 2*thickness, startY + heigh);
    vertex(startX0 + thickness/2, startY + 2*heigh); // point
    vertex(startX0 - thickness, startY + heigh);
    vertex(startX0, startY + heigh);
    vertex(startX0, startY);
    endShape();
  }
  pop();

}

function addCardsSequence() {
  //print(frameCount);
  const speed = 2, limitSequence = 97/speed, correction = 0.14*speed; //Correction is needed because the scaled board appears lower than before
  const ratio = h/3.06; //3.06 factor was found by experiment. See models specs.xlsx

  if (frameCount < limitSequence) {
    push();
    imageMode(CORNER);
    image(cardsImage, frameCount*speed*ratio, (topOffset - cardHeightOffset*scale/2)*h + correction*frameCount*h, deviceWidth - 2*frameCount*speed*ratio, deviceHeight - (topOffset - cardHeightOffset*scale/2 + frameCount*speed)*h - correction*frameCount*h);
    pop();

  } else if (frameCount < 4.5*limitSequence) { // adding 3 more cards
    if (frameCount == ceil(limitSequence)) { // execute once
      message1 = "Sets on"; message2 = "board: ";
      cardRows++;
      scale /= scaleFactor;

      const selectionOffset = -30; //-20
      rowImages.splice(0, rowImages.length); // delete all elements from the rowImages array
      for (let i = 0; i < 3; i++) {
        rowImages[i] = [];
        showCardGraphics(unusedCardCounter + i);
        //get the new card that is about to be inserted on board
        rowImages[i][2] = g.get(deviceWidth/2 + ((-1)*cardWidthOffset + selectionOffset)*scale*p - (shapeWidth + 2*shapeWidthOffset)*scale*p/2, topOffset*h - cardHeightOffset*scale*h/2 + (0*cardHeightOffset + selectionOffset)*scale*h, (shapeWidth + 2*shapeWidthOffset - 2*selectionOffset)*scale*p, (cardHeight - 4*selectionOffset)*scale*h);
      }
      //const speed = 40; //40
      //const animationLimit = 2800/speed; //3000
      //frameCount = 2*animationLimit;
      frameCount = 170;
      unusedCardCounter += 3;
      if (unusedCardCounter == cardsTotal) {
        unusedCardCounter = cardRows*cardColumns; //resets the counter to the start of the deck of the closed cards
        shuffleArray(cards, unusedCardCounter); // shuffles the closed cards only, so that the same sets don't appear on board again
      }
    } else { // inserting 3 new cards animaton
      addCardsSequence2();
    }
  } else { // addCardsSequence is finished
    canClick = true;
    addCardsSequenceFlag = false;
    showCards(false); // So that it displays the sets on board
    //cS(true);
  }
}

function addCardsSequence2() { // inserting 3 new cards animaton
  const imageY = [], rectX = [], cardX = [];
  const direction = -1;
  const cardMovementLimit = 10; //10
  const speed = 40; //40
  const animationLimit = 2800/speed; //3000
  const selectionOffset = -20, rectOffset = -12;
  const rectWidth = (shapeWidth + 2*shapeWidthOffset - 2*selectionOffset - 2*rectOffset)*scale*p;
  const rectHeight = (cardHeight - 5*selectionOffset)*scale*h;
  const j = -1;
  for (let i = 0; i < 3; i++) {
    imageY[i] = ((cardRows - 1)*cardHeightOffset + selectionOffset)*scale*h - cardHeightOffset*scale*h/2;
    rectX[i] = deviceWidth/2 + ((i-1)*cardWidthOffset + selectionOffset + rectOffset)*scale*p - (shapeWidth + 2*shapeWidthOffset)*scale*p/2;
    cardX[i] = deviceWidth/2 + (((3*animationLimit - frameCount) - i*cardMovementLimit)*speed + (i-1)*cardWidthOffset + selectionOffset)*scale*p - (shapeWidth + 2*shapeWidthOffset)*scale*p/2;
  }

  push();
  translate(0, topOffset*h);
  imageMode(CORNER);
  rectMode(CORNER);

  //clear the places of the moving cards
  fill(backgroundColor);
  noStroke();
  if (cardX[2] > rectX[2]) { // so that the new incoming card does not move beyond its initial place
    rect(rectX[2], imageY[2], rectWidth - 4*selectionOffset, rectHeight);
  }
  if (cardX[1] > rectX[1]) { // so that the new incoming card does not move beyond its initial place
    rect(rectX[1], imageY[1], rectWidth - 4*selectionOffset, rectHeight);
  }
  if (cardX[0] > rectX[0]) { // so that the new incoming card does not move beyond its initial place
    rect(rectX[0], imageY[0], rectWidth - 4*selectionOffset, rectHeight);
  }

  //show moving cards
  if (cardX[2] > rectX[2]) { // so that the new incoming card does not move beyond its initial place
    image(rowImages[2][2], cardX[2], imageY[2], rectWidth, rectHeight); // show the incoming card
  } else {
    image(rowImages[2][2], rectX[2], imageY[2], rectWidth, rectHeight); // show the incoming card
  }
  if (cardX[1] > rectX[1]) { // so that the new incoming card does not move beyond its initial place
    image(rowImages[1][2], cardX[1], imageY[1], rectWidth, rectHeight); // show the incoming card
  } else {
    image(rowImages[1][2], rectX[1], imageY[1], rectWidth, rectHeight); // show the incoming card
  }
  if (cardX[0] > rectX[0]) { // so that the new incoming card does not move beyond its initial place
    image(rowImages[0][2], cardX[0], imageY[0], rectWidth, rectHeight); // show the incoming card
  } else {
    image(rowImages[0][2], rectX[0], imageY[0], rectWidth, rectHeight); // show the incoming card
  }
  pop();

}

function reduceCardsSequence() {
  const speed = 2, limitSequence = 115/speed, correction = 0.10*speed; //Correction is needed because the scaled board appears lower than before
  const ratio = h/3.06; //3.06 factor was found by experiment. See models specs.xlsx

  if (frameCount < limitSequence) {
    push();
    imageMode(CORNER);
    image(cardsImage, -frameCount*speed*ratio, (topOffset - cardHeightOffset*scale/2)*h - correction*frameCount*h, deviceWidth + 2*frameCount*speed*ratio, deviceHeight - (topOffset - cardHeightOffset*scale/2 - frameCount*speed)*h + correction*frameCount*h);
    pop();
  } else { // frameCount is finished
    cardRows--; // card rows must be decreased here so that the addCardsSequence is not initiated
    canClick = true;
    reduceCardsSequenceFlag = false;
    scale *= scaleFactor;
    //cS(true);
    //unusedCardCounter -= 3; // This command must not be executed because the second insertion of 3 new cards will have been used before and will form a set.
    showCards(false); // So that it displays the sets on board
  }
}

function timesUpSequence() {
  const speed = 1.5, limitSequence = 180, limitGrow = speed*9, limitShrink = 1.6*limitGrow;
  let offset;

  if (timesupFrameCount < limitSequence) {
    if (timesupFrameCount < limitGrow) {
      offset = speed*timesupFrameCount;
    } else if (timesupFrameCount < limitShrink) {
      offset = speed*(limitGrow*2 - timesupFrameCount);
    } else {
      offset = speed*(limitGrow*2 - limitShrink);
    }
    push();
    rectMode(LEFT);
    noStroke();
    fill(backgroundColor);
    rect(0, 75*h, deviceWidth, 60*h); //hide all the info line

    stroke(128, 35, 35);
    strokeWeight(7*p);
    textAlign(CENTER, CENTER);
    fill(255, 70, 70);
    textSize((40 + offset)*p);
    text("TIME'S UP", deviceWidth/2, 100*h);
    pop();
  } else { // timesupFrameCount is finished
    timesUpSequenceFlag = false;
    canClick = true;
    newEntryPos = newEntryPosition(score);
    gameStatus = 0; // menu
  }
  timesupFrameCount++;
}

function threeCardsSequence(setText, scoreVariance, borderColor, letterColor, varianceColor) {
  const speed = 8, limitSequence = 60, limitMovementText = 22, limitMovementVariance = 10;
  let offsetText, offsetVariance;
  if (! onePlayer) {
    scoreVariance /= 10;
  }

  if (frameCount < limitSequence) {
    if (frameCount < limitMovementText) {
      offsetText = speed*frameCount;
    } else {
      offsetText = speed*limitMovementText;
    }
    if (frameCount < limitMovementVariance) {
      offsetVariance = 0;
    } else {
      offsetVariance = speed*frameCount/2.9 + limitMovementVariance;
    }

    push();
    rectMode(CORNER);
    noStroke();
    fill(backgroundColor);
    //rect(deviceWidth - 85*p, topOffset*h - 97*h, 170*p, 60*h); //hide the buttons
    if (onePlayer) {
      rect(120*p, 0, deviceWidth - 120*p, 135*h); //hide the score and the buttons
      rect(0, 75*h, 120*p, 60*h); //hide the score and the buttons
    } else {
      rect(0, 0, deviceWidth, (topOffset - 70)*h); //hide the score and the buttons
    }

    fill(letterColor);
    stroke(borderColor);
    strokeWeight(7*p);
    textSize(45*p);
    textAlign(CENTER, BOTTOM);
    if (setAnnounced == 0 || setAnnounced == 1) {
      text(setText, deviceWidth - (-40 + offsetText)*p, 130*h);
    } else { // 2
      text(setText, (-40 + offsetText)*p, 130*h);
    }

    showScore();
    fill(varianceColor);
    noStroke();
    textSize(30*p);
    if (setAnnounced == 0 || setAnnounced == 1) {
      text((scoreVariance < 0 ? "":"+") + scoreVariance, deviceWidth - (-40 + offsetVariance)*p, 60*h);
    } else { // 2
      text((scoreVariance < 0 ? "":"+") + scoreVariance, (-40 + offsetVariance)*p, 60*h);
    }
    pop();
  } else { // frameCount is finished
    if (setAnnounced == 0 || setAnnounced == 1) {
      score += scoreVariance;
    } else { // 2
      score2 += scoreVariance;
    }
    if (! addCardsSequenceFlag && ! timesUpSequenceFlag && ! collectCardsSequenceFlag) {
      canClick = true;
    }
    setAnnounced = 0;
    setCount = 0;
    setFlash = -1;

    push();
    rectMode(CORNER);
    noStroke();
    fill(backgroundColor);
    if (onePlayer) {
      rect(170*p, 0, deviceWidth - 170*p, 70*h); //hide the score
    } else {
      rect(0, 0, deviceWidth, 70*h); //hide the first row
    }
    pop();
    showScore(); // So that the final score is shown when the threeCardsSequence overlaps with the timesUpSequence.

    if (setFlag) {
      //πριν το animation της αποχώρησης των 3 φύλλων
      threeCardsSequenceFlag = false;

      frameCount = -1
      getCardRows();
      collectCardsSequenceFlag = true;
      direction = +1;
      canClick = false;
    } else { // No set
      deselectAllCards();
      if (! timesUpSequenceFlag) { // So that the score is not erased when the threeCardsSequence overlaps with the timesUpSequence.
        showCards(false);
      }
      threeCardsSequenceFlag = false;
    }
  }
}

function getCardRows() {
  const selectionOffset = -20; //-20
  rowImages.splice(0, rowImages.length); // delete all elements from the rowImages array

  for (let i = 0; i < 3; i++) {
    let k = selectedCardsArray[i].row;
    let j = selectedCardsArray[i].column - 1;
    rowImages[i] = [];
    //get whole row of the selected card
    rowImages[i][0] = get(0, topOffset*h - cardHeightOffset*scale*h/2 + (k*cardHeightOffset + selectionOffset)*scale*h, deviceWidth, (cardHeight - 5*selectionOffset)*scale*h);
    //get only the selected card
    rowImages[i][1] = get(deviceWidth/2 + (j*cardWidthOffset + selectionOffset)*scale*p - (shapeWidth + 2*shapeWidthOffset)*scale*p/2, topOffset*h - cardHeightOffset*scale*h/2 + (k*cardHeightOffset + selectionOffset)*scale*h, (shapeWidth + 2*shapeWidthOffset - 2*selectionOffset)*scale*p, (cardHeight - 5*selectionOffset)*scale*h);

    showCardGraphics(unusedCardCounter + i);
    //get the new card that is about to be inserted on board
    rowImages[i][2] = g.get(deviceWidth/2 + ((-1)*cardWidthOffset + selectionOffset)*scale*p - (shapeWidth + 2*shapeWidthOffset)*scale*p/2, topOffset*h - cardHeightOffset*scale*h/2 + (0*cardHeightOffset + selectionOffset)*scale*h, (shapeWidth + 2*shapeWidthOffset - 2*selectionOffset)*scale*p, (cardHeight - 5*selectionOffset)*scale*h);
  }
}

function collectCardsSequence() {
  //print(frameCount);
  const k = [], j = [], imageX = [], imageY = [], rectX = [], cardX = [];
  const cardMovementLimit = 10; //10
  const speed = 40; //40
  const animationLimit = 2800/speed; //3000
  const selectionOffset = -20, rectOffset = -12;
  const rectWidth = (shapeWidth + 2*shapeWidthOffset - 2*selectionOffset - 2*rectOffset)*scale*p;
  const rectHeight = (cardHeight - 5*selectionOffset)*scale*h;
  for (let i = 0; i < 3; i++) {
    k[i] = selectedCardsArray[i].row;
    j[i] = selectedCardsArray[i].column - 1;
    imageX[i] = 0;
    imageY[i] = (k[i]*cardHeightOffset + selectionOffset)*scale*h - cardHeightOffset*scale*h/2;
    rectX[i] = deviceWidth/2 + (j[i]*cardWidthOffset + selectionOffset + rectOffset)*scale*p - (shapeWidth + 2*shapeWidthOffset)*scale*p/2;
    cardX[i] = deviceWidth/2 + ((((direction == 1) ? frameCount : 2*animationLimit - frameCount) - i*cardMovementLimit)*speed + j[i]*cardWidthOffset + selectionOffset)*scale*p - (shapeWidth + 2*shapeWidthOffset)*scale*p/2;
  }

  //********* ΑΠΟΧΩΡΗΣΗ ΤΩΝ 3 ΦΥΛΛΩΝ *********
  if ((frameCount < cardMovementLimit) || (frameCount >= animationLimit && frameCount <= animationLimit + cardMovementLimit && direction == -1)) { // show 1st card only
    push();
    translate(0, topOffset*h);
    imageMode(CORNER);
    rectMode(CORNER);
    //show card row
    if (cardX[0] > rectX[0]) { // so that the new incoming card does not move beyond its initial place
      //image(rowImages[0][0], imageX[0], imageY[0]);
    }
    //clear the place of the moving cards
    fill(backgroundColor);
    noStroke();
    if (direction == -1) { // so that the second card in the same row does not appear again between transitions
      rect(rectX[2], imageY[2], rectWidth, rectHeight);
      rect(rectX[1], imageY[1], rectWidth, rectHeight);
    }
    if (cardX[0] > rectX[0]) { // so that the new incoming card does not move beyond its initial place
      rect(rectX[0], imageY[0], rectWidth, rectHeight);
      //show moving card
      if (direction == 1) {
        image(rowImages[0][1], cardX[0], imageY[0], rectWidth, rectHeight);
      } else {
        image(rowImages[0][2], cardX[0], imageY[0], rectWidth, rectHeight);
      }
    }
    pop();
  } else if ((frameCount >= cardMovementLimit && frameCount < 2*cardMovementLimit) || (frameCount > animationLimit + cardMovementLimit && frameCount <= animationLimit + 2*cardMovementLimit && direction == -1)) { // show 1st and 2nd card
    push();
    translate(0, topOffset*h);
    imageMode(CORNER);
    rectMode(CORNER);
    //show card rows
    if (cardX[1] > rectX[1]) { // so that the old row with the old selected cards does not become visible
      image(rowImages[1][0], imageX[1], imageY[1]);
    }
    if (cardX[0] > rectX[0]) { // so that the old row with the old selected cards does not become visible
      image(rowImages[0][0], imageX[0], imageY[0]);
    }
    //clear the places of the moving cards
    fill(backgroundColor);
    noStroke();
    if (direction == -1) { // so that the second card in the same row does not appear again between transitions
      rect(rectX[2], imageY[2], rectWidth, rectHeight);
    }
    if (cardX[1] > rectX[1]) { // so that the new incoming card does not move beyond its initial place
      rect(rectX[1], imageY[1], rectWidth, rectHeight);
    }
    if (cardX[0] > rectX[0]) { // so that the new incoming card does not move beyond its initial place
      rect(rectX[0], imageY[0], rectWidth, rectHeight);
    }
    //show moving cards
    if (cardX[1] > rectX[1]) { // so that the new incoming card does not move beyond its initial place
      if (direction == 1) {
        image(rowImages[1][1], cardX[1], imageY[1], rectWidth, rectHeight); // show the outgoing card
      } else {
        image(rowImages[1][2], cardX[1], imageY[1], rectWidth, rectHeight); // show the incoming card
      }
    }
    if (cardX[0] > rectX[0]) { // so that the new incoming card does not move beyond its initial place
      if (direction == 1) {
        image(rowImages[0][1], cardX[0], imageY[0], rectWidth, rectHeight); // show the outgoing card
      } else {
        image(rowImages[0][2], cardX[0], imageY[0], rectWidth, rectHeight); // show the incoming card
      }
    }
    pop();
  } else if ((frameCount >= 2*cardMovementLimit && frameCount < animationLimit) || (frameCount > animationLimit + 2*cardMovementLimit && frameCount <= 2*animationLimit && direction == -1)) { // show 1st, 2nd card and 3rd card
    push();
    translate(0, topOffset*h);
    imageMode(CORNER);
    rectMode(CORNER);
    //show card rows
    if (cardX[2] > rectX[2]) { // so that the old row with the old selected cards does not become visible
      image(rowImages[2][0], imageX[2], imageY[2]);
    }
    if (cardX[1] > rectX[1]) { // so that the old row with the old selected cards does not become visible
      image(rowImages[1][0], imageX[1], imageY[1]);
    }
    if (cardX[0] > rectX[0]) { // so that the old row with the old selected cards does not become visible
      image(rowImages[0][0], imageX[0], imageY[0]);
    }
    //clear the places of the moving cards
    fill(backgroundColor);
    noStroke();
    if (cardX[2] > rectX[2]) { // so that the new incoming card does not move beyond its initial place
      rect(rectX[2], imageY[2], rectWidth, rectHeight);
    }
    if (cardX[1] > rectX[1]) { // so that the new incoming card does not move beyond its initial place
      rect(rectX[1], imageY[1], rectWidth, rectHeight);
    }
    if (cardX[0] > rectX[0]) { // so that the new incoming card does not move beyond its initial place
      rect(rectX[0], imageY[0], rectWidth, rectHeight);
    }
    //show moving cards
    if (cardX[2] > rectX[2]) { // so that the new incoming card does not move beyond its initial place
      if (direction == 1) {
        image(rowImages[2][1], cardX[2], imageY[2], rectWidth, rectHeight); // show the outgoing card
      } else {
        image(rowImages[2][2], cardX[2], imageY[2], rectWidth, rectHeight); // show the incoming card
      }
    } else {
      if (direction == 1) {
        image(rowImages[2][1], rectX[2], imageY[2], rectWidth, rectHeight); // show the outgoing card
      } else {
        image(rowImages[2][2], rectX[2], imageY[2], rectWidth, rectHeight); // show the incoming card
      }
    }
    if (cardX[1] > rectX[1]) { // so that the new incoming card does not move beyond its initial place
      if (direction == 1) {
        image(rowImages[1][1], cardX[1], imageY[1], rectWidth, rectHeight); // show the outgoing card
      } else {
        image(rowImages[1][2], cardX[1], imageY[1], rectWidth, rectHeight); // show the incoming card
      }
    } else {
      if (direction == 1) {
        image(rowImages[1][1], rectX[1], imageY[1], rectWidth, rectHeight); // show the outgoing card
      } else {
        image(rowImages[1][2], rectX[1], imageY[1], rectWidth, rectHeight); // show the incoming card
      }
    }
    if (cardX[0] > rectX[0]) { // so that the new incoming card does not move beyond its initial place
      if (direction == 1) {
        image(rowImages[0][1], cardX[0], imageY[0], rectWidth, rectHeight); // show the outgoing card
      } else {
        image(rowImages[0][2], cardX[0], imageY[0], rectWidth, rectHeight); // show the incoming card
      }
    } else {
      if (direction == 1) {
        image(rowImages[0][1], rectX[0], imageY[0], rectWidth, rectHeight); // show the outgoing card
      } else {
        image(rowImages[0][2], rectX[0], imageY[0], rectWidth, rectHeight); // show the incoming card
      }
    }
    pop();
  } else { // 3 cards animation is finished
    //πριν το animation της εισαγωγής των 3 νέων φύλλων
    if (direction == 1) { // change the cards only when they have left the board
      changeSelectedCards();
    }

    if (direction == -1) {
      deselectAllCards(); // Cards must be selected when they leave the board
    }

    if (! timesUpSequenceFlag && frameCount >= 2*animationLimit) { // So that the score is not erased when the threeCardsSequence overlaps with the timesUpSequence.
      showCards(false);
    }
    //******* ΕΙΣΑΓΩΓΗ ΤΩΝ 3 ΝΕΩΝ ΦΥΛΛΩΝ *********
    //μετά το animation της εισαγωγής των 3 νέων φύλλων
    if (direction == -1) {
      collectCardsSequenceFlag = false;
      canClick = true;
      // delete all elements from the local arrays
      k.splice(0, k.length);
      j.splice(0, j.length);
      imageX.splice(0, imageX.length);
      imageY.splice(0, imageY.length);
      rectX.splice(0, rectX.length);
      cardX.splice(0, cardX.length);
      if (cardRows > 4) { // reduce the cards on the board when a set is made and the cards on board are more than 12
        //cardRows--; // card rows must not be decreased here because the addCardsSequence is initiated
        //startingScale = scale;
        frameCount = -1;
        canClick = false;
        cardsImage = get(0, (topOffset - cardHeightOffset*scale/2)*h, deviceWidth, deviceHeight - (topOffset - cardHeightOffset*scale/2)*h);
        reduceCardsSequenceFlag = true;
      }
      //cS(true);
    } else {
      direction = -direction;
      for (i = 0; i < cardsTotal; i++) {
        cards[i].selected = false; // deselects all the cards
      }
      cardsSelected = 0;
    }
  }
}

function deselectAllCards() {
  selectedCardsArray.splice(0, selectedCardsArray.length); // deletes all selectedCardsArray elements before return
  for (let i = 0; i < cardsTotal; i++) {
    cards[i].selected = false; // deselects all the cards
    cards[i].row = 9;
    cards[i].column = 9;
  }
  cardsSelected = 0;
}

function changeSelectedCards() {
  let match;
  for (let i = 0; i < 3; i++) {
    match = selectedCardsArray[i].row*3 + selectedCardsArray[i].column;
    cards[match].selected = false;
    cards[match].row = 9;
    cards[match].column = 9;
    [cards[match], cards[unusedCardCounter]] = [cards[unusedCardCounter], cards[match]]; //swaps the selected card with the first unused card of the deck
    unusedCardCounter++;
    if (unusedCardCounter == cardsTotal) {
      unusedCardCounter = cardRows*cardColumns; //resets the counter to the start of the deck of the closed cards
      shuffleArray(cards, unusedCardCounter); // shuffles the closed cards only, so that the same sets don't appear on board again
    }
  }
}

function showCardGraphics(counter) {
  const selectionOffset = 0; //10
  g.background(backgroundColor);
  g.push();
  g.translate(0, topOffset*h);
  g.imageMode(CENTER);
  g.rectMode(CENTER);
  g.noStroke();
  //shadow
  g.fill(shadowColor);
  g.rect(deviceWidth/2 + (shadowOffset + (-1)*cardWidthOffset)*scale*p, (shadowOffset + 0*cardHeightOffset)*scale*h, (shapeWidth + 2*shapeWidthOffset)*scale*p, cardHeight*scale*h, 30*scale*p);
  //card
  g.fill(255);
  g.rect(deviceWidth/2 + ((-1)*cardWidthOffset + selectionOffset)*scale*p, (0*cardHeightOffset + selectionOffset)*scale*h, (shapeWidth + 2*shapeWidthOffset)*scale*p, cardHeight*scale*h, 30*scale*p);
  g.tint(colors[cards[counter].color]);
  for (let i = 0; i <= cards[counter].amount; i++) { // each card's shapes
    g.image(shapes[cards[counter].shape][cards[counter].fill], deviceWidth/2 + ((-1)*cardWidthOffset + selectionOffset)*scale*p, ((i - cards[counter].amount/2)*shapeBetweenOffset + 0*cardHeightOffset + selectionOffset)*scale*h, shapeWidth*scale*p, shapeHeight*scale*h);
  }
  g.pop();
}

function showOneCard(counter, row, column) {
  let selectionOffset = 0;
  push();
  translate(0, topOffset*h);
  imageMode(CENTER);
  rectMode(CENTER);
  noStroke();
  let k = row;
  let j = column - 1;
  //print("counter:", counter, k, j, cards[counter].onBoard);
  //background to erase yellow selection area
  fill(backgroundColor);
  selectionOffset = -30;
  rect(deviceWidth/2 + (j*cardWidthOffset + selectionOffset)*scale*p, (k*cardHeightOffset + selectionOffset)*scale*h, (shapeWidth + 2*shapeWidthOffset - 2*selectionOffset)*scale*p, (cardHeight - 2*selectionOffset)*scale*h, 30*scale*p);
  //shadow
  fill(shadowColor);
  rect(deviceWidth/2 + (shadowOffset + j*cardWidthOffset)*scale*p, (shadowOffset + k*cardHeightOffset)*scale*h, (shapeWidth + 2*shapeWidthOffset)*scale*p, cardHeight*scale*h, 30*scale*p);
  //card
  if (cards[counter].selected) {
    fill(255, 255, 225);
    selectionOffset = -30;
  } else {
    fill(255);
    selectionOffset = 0;
  }
  rect(deviceWidth/2 + (j*cardWidthOffset + selectionOffset)*scale*p, (k*cardHeightOffset + selectionOffset)*scale*h, (shapeWidth + 2*shapeWidthOffset)*scale*p, cardHeight*scale*h, 30*scale*p);
  tint(colors[cards[counter].color]);
  for (let i = 0; i <= cards[counter].amount; i++) { // each card's shapes
    image(shapes[cards[counter].shape][cards[counter].fill], deviceWidth/2 + (j*cardWidthOffset + selectionOffset)*scale*p, ((i - cards[counter].amount/2)*shapeBetweenOffset + k*cardHeightOffset + selectionOffset)*scale*h, shapeWidth*scale*p, shapeHeight*scale*h);
  }
  pop();
}

function showCards(hideCards) {
  //document.body.style.backgroundColor = backgroundColor; //change the color outside the canvas
  //background(backgroundColor);
  push();
  fill(backgroundColor);
  noStroke();
  rect(0, 0, deviceWidth, (topOffset - 67)*h); // clears the top part
  pop();
  if (onePlayer) { previousCounter = clockCounter; } //So that the clock doesn't blink

  if (! hideCards) { displayCardRows(); }
  if (cS() < addCardsLimit && clockCounter > 300) { // So that it doesn't add cards when the timer is about to end. 300 millisecs are 4 secs. Last 60 millisecs don't count.
    message1 = "No sets on board.";
    message2 = "Adding 3 more cards...";
    shuffleArray(cards, cardRows*cardColumns); // shuffles the closed cards only, so that the sets already made don't appear on board again. The start of the shuffle is the first unused card in deck.
    unusedCardCounter = cardRows*cardColumns;
    frameCount = -1;
    canClick = false;
    //startingScale = scale;
    cardsImage = get(0, (topOffset - cardHeightOffset*scale/2)*h, deviceWidth, deviceHeight - (topOffset - cardHeightOffset*scale/2)*h);
    addCardsSequenceFlag = true;
  }

  showScore();

  push();
  imageMode(CENTER);
  rectMode(CORNER);
  textSize(25*p);
  textAlign(CENTER, BOTTOM);
  noStroke();
  fill(0);
  // text(message1, 10*p, topOffset*h - 93*h); // left place
  // text(message2 + ((cS(false) < 1) ? " " : cS(false)), 10*p, topOffset*h - 65*h); // left place
  text(message1, deviceWidth/2, topOffset*h - 95*h);
  text(message2 + ((cS(false) < 1) ? " " : cS(false)), deviceWidth/2, topOffset*h - 67*h);

  if (message1 == "Sets on") { //don't show image when adding cards
    if (onePlayer) {
      image(exitButton, 35*p, topOffset*h - 96*h, 60*p, 67*h);
      image(pauseButton, deviceWidth - 35*p, topOffset*h - 97*h, 50*p, 50*h);
    } else { //two players
      image(exitButton, deviceWidth/2, topOffset*h - 160*h, 60*p, 67*h); // middle place
      strokeWeight(5*p);
      textSize(38*p);
      stroke(player2DarkColor);
      if (setAnnounced == 2 && setFlash == 1) {
        fill(player2LightColor);
      } else {
        fill(backgroundColor);
      }
      rect(10*p, topOffset*h - 128*h, 70*p, 53*h, 10*p);
      noStroke();
      fill(player2DarkColor);
      text("SET", 45*p, topOffset*h - 79*h);
      stroke(player1DarkColor);
      if (setAnnounced == 1 && setFlash == 1) {
        fill(player1LightColor);
      } else {
        fill(backgroundColor);
      }
      rect(deviceWidth - 80*p, topOffset*h - 128*h, 70*p, 53*h, 10*p);
      noStroke();
      fill(player1DarkColor);
      text("SET", deviceWidth - 45*p, topOffset*h - 79*h);
    }
  }
  pop();
}

function displayCardRows() {
  let counter = 0, selectionOffset = 0;
  document.body.style.backgroundColor = backgroundColor; //change the color outside the canvas
  background(backgroundColor);
  push();
  translate(0, topOffset*h);
  imageMode(CENTER);
  rectMode(CENTER);
  noStroke();
  for (let k = 0; k < cardRows; k++) { // one column of 3 cards
    for (let j = -1; j < cardColumns - 1; j++) { // one row of cards
      //shadow
      fill(shadowColor);
      rect(deviceWidth/2 + (shadowOffset + j*cardWidthOffset)*scale*p, (shadowOffset + k*cardHeightOffset)*scale*h, (shapeWidth + 2*shapeWidthOffset)*scale*p, cardHeight*scale*h, 30*scale*p);
      //card
      fill(255);
      rect(deviceWidth/2 + (j*cardWidthOffset + selectionOffset)*scale*p, (k*cardHeightOffset + selectionOffset)*scale*h, (shapeWidth + 2*shapeWidthOffset)*scale*p, cardHeight*scale*h, 30*scale*p);
      tint(colors[cards[counter].color]);
      for (let i = 0; i <= cards[counter].amount; i++) { // each card's shapes
        image(shapes[cards[counter].shape][cards[counter].fill], deviceWidth/2 + (j*cardWidthOffset + selectionOffset)*scale*p, ((i - cards[counter].amount/2)*shapeBetweenOffset + k*cardHeightOffset + selectionOffset)*scale*h, shapeWidth*scale*p, shapeHeight*scale*h);
      }
      //cards[counter].onBoard = true;
      counter++;
    }
  }
  pop();
}

function createCards() {
  let id = 0;
  for (let col = 0; col < 3; col++) {
    for (let shap = 0; shap < 3; shap++) {
      for (let am = 0; am < 3; am++) {
        for (let fil = 0; fil < 3; fil++) {
          cards.push(new Card(id, col, shap, am, fil));
          id++;
        }
      }
    }
  }
}

function shuffleArray(array, start) {
  for (let i = array.length - 1; i > start; i--) {
    let j = Math.floor(Math.random() * (i + 1));
    if (j < start) {
      if (j + start < cardsTotal) {
        j += start;
      } else {
        j += (start - j);
      }
    }
    [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
}

function inputName() {
  //print("enter new player name");
  buttonOK.show();

  push();
  background(backgroundColor);
  textFont(hiScoresFont);
  textAlign(CENTER, TOP);
  fill(212, 175, 55);
  textSize(30*p);
  stroke(106, 87, 28);
  strokeWeight(3*p);
  text("Congratulations!", deviceWidth/2, 10*p);
  fill(0);
  textSize(17*p);
  noStroke();
  text("You made it to the leaderboard.\nEnter your name and press\nOK or → on keyboard", deviceWidth/2, 65*h);
  pop();

  inp.position((windowWidth + deviceWidth)/2 - 225*p, 150*h);
  inp.show();
  inp.elt.focus();
}

function inputEvent() {
  if (this.value().trimStart() != "") {
    playerName = this.value().trimStart();
    buttonOK.removeAttribute('disabled');
  } else {
    buttonOK.attribute('disabled', '');
    playerName = "";
  }
}

function keyPressed() {
  if (keyCode === RETURN && playerName != "") {
    hideInput();
  }
}

function hideInput() {
  inp.elt.autofocus = false;
  inp.elt.blur();
  inp.hide();
  buttonOK.hide();
  gameStatus = 2; // leaderboard
  //print(score);
  //getProfileData();
  updateLeaderboard();
  checkNewName();
  showHiscores();
}

function updateLeaderboard() {
  //newEntryPos = newEntryPosition(score);
  if (newEntryPos < 99) {
    entryShown = true;
    newHiScore = true;
    new_entry = [playerName, score];
    updateEntries();
  }
}

function checkNewName() {
  if (entryShown) {
   entryShown = false;
   if (newHiScore) {
     newHiScore = false;
     entries[newEntryPos][0] = playerName;
     if (score > scoreSession) {
       sendEmail(playerName, score);
     }
   }
  }
}

function nameCharacters(name, widthLimit) {
  let widthCurrent;
  for (let i = 0; i < name.length; i++) {
    widthCurrent = textWidth(name.substring(0, i));
    if (widthCurrent > widthLimit) {
      return i;
    }
  }
  return name.length;
}

function createEntries() {
  let i;
  for (i = 0; i < hiscores.length; i++) {
    list.push(hiscores[i].split(","));
  }
  for (i = 0; i < list.length; i++) {
    entries.push([list[i][0], int(list[i][1])]);
  }
}

function updateEntries() {
  entries.splice(newEntryPos, 0, new_entry); // Adds the new entry
  entries.splice(entries.length - 1, 1); // Deletes the last entry
}

function newEntryPosition(sc) {
  for (let i = 0; i < entries.length; i++) {
    if (sc > entries[i][1]) {
      return i;
    }
  }
  return 99;
}

function getProfileData() {
  scoreSession = getBestScore(playerName);
}

function getBestScore(name) {
  for (let i = 0; i < entries.length; i++) {
    if (entries[i][0] == name) {
      return entries[i][1];
    }
  }
  return 0;
}

function showHiscores() {
  gameStatus = 2;
  document.body.style.backgroundColor = "black"; //change the color outside the canvas
  background(backgroundColor);
  let nameWidthLimit = 145*p;
  push();
  imageMode(CORNER);
  noStroke();
  textAlign(LEFT, TOP);
  textFont(hiScoresFont);
  image(highScoresTable, 0, 0, deviceWidth, deviceHeight);
  image(closeButton, deviceWidth - 35*p, 5*h, 35*p, 35*p);

  textSize(22*p);
  for (let i = 0; i < entries.length; i++) {
    textAlign(LEFT);
    fill(255);
    text(entries[i][0].substring(0, nameCharacters(entries[i][0], nameWidthLimit)), 53*p, 38.6*h*i + 64*h);
    textAlign(RIGHT);
    fill(252, 186, 3);
    text(entries[i][1], 255*p, 38.6*h*i + 65*h);
  }
  if (newEntryPos < 99) {
    noFill();
    strokeWeight(3*p);
    stroke(255, 128, 0);
    rect(40*p, 38.6*h*newEntryPos + 66*h, 229*p, 34*h, 10*p);
    newEntryPos = 99;
  }
  pop();
}

function sendEmail(nck, scr) {
  let params = {
  from_name: nck,
  message: "Set Score: " + scr
  };
  emailjs.send( 'service_d7c6m1o', 'template_fwhw6qj', params, 'user_qCR7E72WNe13QFiRp0fRC')
  .then(function(response) {
     console.log('Mail send SUCCESS!', response.status, response.text);
  }, function(error) {
     console.log('Mail send FAILED...', error);
  });
}

function createButtons() {
  buttonOK = createButton("OK");
  buttonOK.mousePressed(hideInput);
  buttonOK.size(80*p, 40*h);
  buttonOK.position((windowWidth - deviceWidth)/2 + 105*p, 200*h);
  buttonOK.class("OK_button");
  buttonOK.attribute('disabled', '');
  buttonOK.hide();

  inp = createInput('');
  inp.addClass('inputbox');
  inp.style('font-size', (20*p).toString()+'px');
  inp.size(170*p, 26*p);
  inp.input(inputEvent);
  inp.elt.autofocus = true;
  inp.hide();
  document.querySelector('.inputbox').ontouchend = function() { //This is for the iOS only which does not open the keyboard
    document.querySelector('.inputbox').focus();
  };
  document.querySelector('.inputbox').onblur = function() { //This is for the iOS only which does not open the keyboard
    document.querySelector('.inputbox').autofocus;
    document.querySelector('.inputbox').focus();
  };

}

function howToPlay() {
  document.body.style.backgroundColor = infoColor; //change the color outside the canvas
  background(infoColor); //change the color inside the canvas

  push();
  imageMode(CORNER);
  rectMode(CENTER);
  image(infoFrame, 0, 0, deviceWidth, deviceHeight);

  translate(deviceWidth/2 + 13*p, 150*h);
  textSize(33*p);
  textAlign(CENTER, BOTTOM);
  strokeWeight(7*p);
  stroke(59, 77, 79);
  fill(237, 255, 240);
  text("Do you know", 0, 0);
  text("how to play", 0, 50*h);
  text("Set ?", 0, 100*h);

  strokeWeight(4*p);
  fill(120, 220, 120);
  stroke(60, 110, 60);
  rect(0, 220*h, 140*p, 70*h, 20*p);
  fill(200);
  stroke(100);
  rect(0, 340*h, 140*p, 50*h, 20*p);
  noStroke();
  fill(50, 85, 50);
  textSize(50*p);
  text("NO !", 0, 250*h);
  fill(80);
  textSize(40*p);
  text("yes", 0, 359*h);
  pop();
}

function info1() {
  const headerSize = 30, textingSize = 17;
  document.body.style.backgroundColor = infoColor; //change the color outside the canvas
  background(infoColor); //change the color inside the canvas

  push();
  imageMode(CORNER);
  textAlign(LEFT, TOP);
  image(infoFrame, 0, 0, deviceWidth, deviceHeight);
  image(closeButton, deviceWidth - 50*p, 48*h, 35*p, 35*p);
  image(rightArrowButton, deviceWidth - 50*p, deviceHeight - 54*h, 35*p, 35*p);

  textLeading(22*h); //line spacing

  textSize(headerSize*p);
  strokeWeight(5*p);
  stroke(59, 77, 79);
  fill(237, 255, 240);
  text("Objective", 85*p, 55*h);

  textSize(textingSize*p);
  noStroke();
  fill(0, 50, 150);
  text("The objective of this game is to make as many sets as possible, either against the timer or another player.", 50*p, 100*h, 215*p, 450*h);

  textSize(headerSize*p);
  strokeWeight(5*p);
  stroke(59, 77, 79);
  fill(237, 255, 240);
  text("What is a set ?", 50*p, 215*h);

  textSize(textingSize*p);
  noStroke();
  fill(0, 50, 150);
  text("A set is a certain combination of three cards. For each one of the four categories of features — color, number, shape, and shading — the three cards must display that feature as either a) all the same, or b) all different. Put another way: For each feature the three cards must avoid having two cards showing one version of the feature and the remaining card showing a different version.", 50*p, 260*h, 215*p, 450*h);

  pop();
}

function info2() {
  const headerSize = 30, textingSize = 15;
  document.body.style.backgroundColor = infoColor; //change the color outside the canvas
  background(infoColor); //change the color inside the canvas


  push();
  imageMode(CORNER);
  textAlign(LEFT, TOP);
  image(infoFrame, 0, 0, deviceWidth, deviceHeight);
  image(closeButton, deviceWidth - 50*p, 48*h, 35*p, 35*p);
  image(rightArrowButton, deviceWidth - 50*p, deviceHeight - 54*h, 35*p, 35*p);
  image(leftArrowButton, 43*p, deviceHeight - 54*h, 35*p, 35*p);

  textLeading(22*h); //line spacing

  textSize(textingSize*p);
  noStroke();
  fill(0, 50, 150);
  text("For example, the three cards in the image below form a set, because all 4 of their features are different on each card.", 50*p, 90*h, 215*p, 450*h);
  image(exampleImage1, 50*p, 175*h, 200*p, 100*h);
  text("The three cards in the image below also form a set, because 2 features are the same on each card (color and number), and 2 features are different on each card (shape and shading).", 50*p, 280*h, 215*p, 450*h);
  image(exampleImage2, 50*p, 410*h, 200*p, 100*h);
  text("Keep in mind that for any two given cards, there is one and only one card in the deck that forms a set with the other two.", 50*p, 510*h, 215*p, 450*h);

  pop();
}

function info3() {
  const headerSize = 30, textingSize = 16;
  document.body.style.backgroundColor = infoColor; //change the color outside the canvas
  background(infoColor); //change the color inside the canvas

  push();
  imageMode(CORNER);
  textAlign(LEFT, TOP);
  image(infoFrame, 0, 0, deviceWidth, deviceHeight);
  image(closeButton, deviceWidth - 50*p, 48*h, 35*p, 35*p);
  image(leftArrowButton, 43*p, deviceHeight - 54*h, 35*p, 35*p);

  textLeading(22*h); //line spacing

  textSize(headerSize*p);
  strokeWeight(5*p);
  stroke(59, 77, 79);
  fill(237, 255, 240);
  text("Credits", 50*p, 90*h);

  textSize(textingSize*p);
  noStroke();
  fill(0, 50, 150);
  text("Coding and shapes design by Panos Tsikogiannopoulos (pantsik2@gmail.com)\n\nGame engine: Javascript with the p5.js library.\n\nSound effects from freesound.org.\n\nMore information about the game Set is available on Wikipedia: en.wikipedia.org/wiki/\nSet_(card_game)", 50*p, 145*h, 210*p, 450*h);

  pop();
}

function iOS() {
  return [
    'iPad Simulator',
    'iPhone Simulator',
    'iPod Simulator',
    'iPad',
    'iPhone',
    'iPod'
  ].includes(navigator.platform)
  // iPad on iOS 13 detection
  || (navigator.userAgent.includes("Mac") && "ontouchend" in document)
}

class Card {
  constructor(i, col, shap, am, fil) {
    this.id = i;
    this.selected = false;
    this.color = col;
    this.shape = shap;
    this.amount = am;
    this.fill = fil;
    this.row = 9;
    this.column = 9;
  }
}
